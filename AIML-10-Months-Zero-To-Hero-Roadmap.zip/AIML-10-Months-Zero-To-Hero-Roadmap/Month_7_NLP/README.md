# Month_7_NLP

Text processing, Transformers

Place notes, assignments, and projects here.