# Month_9_Portfolio_Projects

Real-world projects and README templates

Place notes, assignments, and projects here.