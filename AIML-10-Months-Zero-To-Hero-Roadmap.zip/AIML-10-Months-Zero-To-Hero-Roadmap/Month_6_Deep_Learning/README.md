# Month_6_Deep_Learning

Neural networks, CNNs, RNNs

Place notes, assignments, and projects here.