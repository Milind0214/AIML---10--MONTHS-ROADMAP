
# Resources (free & recommended)

## Python & Basics
- Python for Everybody (Coursera) - free audit
- W3Schools Python - https://www.w3schools.com/python/
- Kaggle Python Course - https://www.kaggle.com/learn/python

## Math & Stats
- Khan Academy Math (Statistics & Probability) - https://www.khanacademy.org/
- Essence of Linear Algebra (3Blue1Brown series) - YouTube

## ML & DS
- Andrew Ng Machine Learning (Coursera) - free audit
- Scikit-Learn documentation - https://scikit-learn.org/stable/
- Kaggle Learn - https://www.kaggle.com/learn

## Deep Learning & NLP
- Deep Learning Specialization (Coursera) - free audit
- PyTorch Tutorials - https://pytorch.org/tutorials/
- Hugging Face Course - https://huggingface.co/learn/nlp-course

## Deployment & MLOps
- Streamlit docs - https://docs.streamlit.io/
- FastAPI docs - https://fastapi.tiangolo.com/

## Practice & Competitions
- Kaggle Competitions - https://www.kaggle.com/competitions
- LeetCode (for coding practice) - https://leetcode.com/

