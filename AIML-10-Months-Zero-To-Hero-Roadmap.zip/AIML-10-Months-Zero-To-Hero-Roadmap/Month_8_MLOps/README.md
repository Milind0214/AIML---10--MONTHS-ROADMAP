# Month_8_MLOps

Deployment, Docker, CI/CD

Place notes, assignments, and projects here.