# Month_1_Python_Basics

Python fundamentals, NumPy, Pandas

Place notes, assignments, and projects here.