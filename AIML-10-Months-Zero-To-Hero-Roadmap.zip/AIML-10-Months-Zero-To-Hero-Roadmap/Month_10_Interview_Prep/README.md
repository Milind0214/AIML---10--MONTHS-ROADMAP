# Month_10_Interview_Prep

Interviews, resume, Kaggle polish

Place notes, assignments, and projects here.