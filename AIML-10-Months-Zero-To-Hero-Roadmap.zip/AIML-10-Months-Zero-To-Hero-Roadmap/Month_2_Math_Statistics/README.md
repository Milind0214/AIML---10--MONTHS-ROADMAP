# Month_2_Math_Statistics

Linear Algebra, Probability, Calculus

Place notes, assignments, and projects here.